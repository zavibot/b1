'use strict';

/* eslint-disable no-alert */

(async () => {
  const log = (...args) => {
    console.log(...args);
  };

  const formatDate = (dateStamp) => {
    const date = new Date(dateStamp * 1000);

    const day = date.getDate();
    const monthIndex = date.getMonth();
    const year = date.getFullYear();

    return `${day}.${monthIndex + 1}.${year}`;
  };

  const tunnel = (msg) => new Promise((resolve) => (
    chrome.runtime.sendMessage(msg, Bexer.Utils.workOrDie(resolve))
  ));

  const onMutations = new Set();

  window.addEventListener('error', (event) => {
    if (!event.filename || !event.filename.endsWith('inject.js')) {
      return;
    }
    onMutations.clear();
    const plainObject = Bexer.ErrorTransformer.errorEventToPlainObject(event);
    log('Sending error to bg...');
    tunnel({
      type: 'error',
      errorEvent: plainObject,
    });
  });

  const rejHandler = (event) => {
    event.preventDefault();
    log('REJECTED:', event);
    throw event.reason;
  };
  window.addEventListener('unhandledrejection', rejHandler, true);

  const observe = (mutations /* , observer */) => (
    Array.from(onMutations).reduce(
      (accP, f) => accP.then(f(mutations)),
      Promise.resolve(),
    )
  );

  new MutationObserver(observe)
    .observe(document.body, {
      subtree: true,
      childList: true,
    });

  let groupId;
  let groupTitle;
  let groupName;
  let docId;

  const updateGlobalsAsync = async () => {

    const m = window.location.pathname.split('/'); // /groups/foo123 -> '', 'groups', 'foo123'
    if (m.length > 2) {
      groupId = m[2];
    } else {
      const metaUrl = document.querySelector('meta[property="al:android:url"]');
      if (metaUrl) {
        const m = metaUrl.content.match(/\d+/);
        if (m) {
          [groupId] = m;
        }
      }
    }
    groupTitle = document.querySelector('a[href$="ref=group_header"]');
    // if groupTitle is not found then remove notifications counter from document.title.
    groupName = groupTitle ? groupTitle.innerText : document.title.replace(/\(\d+\)/g, '').trim();
    log('Group name is:', groupName);
    log('Group ID is:', groupId);

    docId = await tunnel({ type: 'getDocId', groupId, groupName });
  };

  updateGlobalsAsync();
  onMutations.add(updateGlobalsAsync);

  const unlinkFeed = async () => {
    /* eslint-disable-next-line no-alert */
    if (!window.confirm('Do really you want to unlink google spreadsheet from the group?')) {
      return;
    }
    log('Tunneling unlink...');
    await tunnel({ type: 'unlink', groupId, groupName });
    docId = false;
    document.getElementById('FunnelLink').remove();
    document.getElementById('FunnelUnlinkButton').remove();
  };

  const loadFeed = async () => {
    log('Loading feed...');
    document.getElementById('FunnelTunnelProcess').remove();
    window.scrollTo({ top: 0, behavior: 'smooth' });

    const requests = document.querySelectorAll('#member_requests_pagelet .uiList > li:not([class]) div[class=""]');
    log(`Found ${requests.length} requests.`);
    const records = [...requests].map((request) => {
      const auids = request.querySelectorAll('a[uid]');
      log(`Found ${auids.length} auids.`);
      let record;
      if (auids.length) {
        const auid = auids[0];
        record = [
          ['groupName', groupName],
          ['name', auid.innerText],
          ['userId', auid.getAttribute('href').slice(1)],
          ['url', auid.href],
          ['date', formatDate(request.querySelector('.livetimestamp').dataset.utime)],
        ];
      } else {
        const uid = request.dataset.testid;
        const name = request.querySelector('.lfloat + div > div > div > div > span').innerText;
        record = [
          ['groupName', groupName],
          ['name', name],
          ['userId', uid],
          ['url', `https://www.facebook.com/${uid}`],
          ['date', formatDate(request.querySelector('.livetimestamp').dataset.utime)],
        ];
      }

      request.querySelectorAll('.uiList > li:not([class])').forEach((li) => {
        record.push([li.querySelector('div').innerText, li.querySelector('text').innerText]);
      });
      return record;
    });

    log(`Pushing ${records.length} records...`);
    docId = await tunnel({
      type: 'pushRecords',
      collectedInfo: records,
      docId,
      groupName,
      groupId,
    });
    /* eslint-disable-next-line no-use-before-define */
    tryToAdd();
  };

  const parseFeed = () => {
    log('Parsing feed...');
    let stopTimer;
    const scroll = () => {
      window.scrollTo({ top: document.body.clientHeight, behavior: 'smooth' });
      clearTimeout(stopTimer);
      stopTimer = setTimeout(() => {
        onMutations.delete(scroll);
        loadFeed();
      }, 6000);
    };
    const div = document.createElement('div');
    div.id = 'FunnelTunnelProcess';
    div.innerHTML = '<div>Click to Stop</div>';
    div.querySelector('div').onclick = () => {
      onMutations.delete(scroll);
      clearTimeout(stopTimer);
      loadFeed();
    };
    document.body.prepend(div);

    onMutations.add(scroll);
    scroll();
  };

  let tryToAdd;

  const connectSheet = async () => {
    const result = window.prompt('Paste URL of a sheet or its ID to associate it with this group:', docId || '');
    log('Prompt result: ' + result);
    if (result) {
      log('Got from user this id/url: ' + result);
      try {
        const url = new URL(result);
        // eslint-disable-next-line
        docId = url.pathname.split('/')[3];
      } catch (_) {
        docId = result;
      }
      log('Sending new DocId: ' + docId + '...');
      await tunnel({
        type: 'setDocId',
        docId,
        groupId,
        groupName,
      });
      tryToAdd();
    } else {
      log('Got nothing from the prompt!');
    }
  };

  tryToAdd = () => {
    log('Trying to add...');

    const approveButton = document.querySelector('button[name="approve_all"]');
    if (!approveButton) {
      log('No approve button found.');
      return;
    }
    const buttonClasses = approveButton.getAttribute('class');
    const collectAllHtml = `<button id="FunnelCollectButton" class="${buttonClasses}">Collect All</button>`;
    const connectHtml = `<button id="FunnelConnectButton" class="${buttonClasses}" title="(Re)connect sheet">⇆</button>`;
    const unlinkHtml = `<button id="FunnelUnlinkButton" class="${buttonClasses}">X</button>`;

    if (!document.getElementById('FunnelCollectButton')) {
      approveButton.insertAdjacentHTML('beforebegin', collectAllHtml);
      const collectButton = document.getElementById('FunnelCollectButton');
      collectButton.onclick = parseFeed;
      collectButton.insertAdjacentHTML('beforebegin', connectHtml);
      const connectButton = document.getElementById('FunnelConnectButton');
      connectButton.onclick = connectSheet;
    }
    if (docId) {
      if (!document.getElementById('FunnelUnlinkButton')) {
        document.getElementById('FunnelConnectButton').insertAdjacentHTML(
          'beforebegin',
          unlinkHtml,
        );
        document.getElementById('FunnelUnlinkButton').onclick = unlinkFeed;
      }
      let FunnelLink = document.querySelector('#FunnelLink');
      if (!FunnelLink) {
        document.getElementById('FunnelUnlinkButton').insertAdjacentHTML(
          'beforebegin',
          '<a target="_blank" id="FunnelLink" style="margin-right: 10px;">Google Sheet</a>',
        );
        FunnelLink = document.getElementById('FunnelLink');
      }
      FunnelLink.href = `https://docs.google.com/spreadsheets/d/${docId}`;
    }
  };

  tryToAdd();
  onMutations.add(tryToAdd);
})();
