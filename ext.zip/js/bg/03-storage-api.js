'use strict';

window.apis.storage = {
  get(what) {
    return new Promise((resolve) => (
      chrome.storage.sync.get(
        what ? [what] : null,
        Bexer.Utils.workOrDie((msg) => resolve(what ? msg[what] : msg)),
      )
    ));
  },
  set(what) {
    return new Promise((resolve) => (
      chrome.storage.sync.set(what, Bexer.Utils.workOrDie(resolve))
    ));
  },
};
