'use strict';

(async () => {
  const isStatusOk = (status) => status >= 200 && status < 300;
  const getJsonOrThrow = (res) => Promise.all([res, res.json()])
    .then(([res2, json]) => {
      if (!isStatusOk(res2.status)) {
        throw new Error(`Bad status ${res2.status}: ${JSON.stringify(json)}`);
      }
      return json;
    });

  const getTokenAsync = () => new Promise((resolve) => chrome.identity.getAuthToken(
    { interactive: true },
    Bexer.Utils.workOrDie(resolve),
  ));

  const recordToObject = (record) => (
    record.reduce((acc, [question, answer]) => {
      acc[question] = answer;
      return acc;
    }, {}));

  window.sheetApi = {
    getSheetInfo: async function getSheetInfo(id, cb) {
      const propsPromise = fetch(
        `https://sheets.googleapis.com/v4/spreadsheets/${id}?&fields=sheets.properties`,
        {
          headers: new Headers({
            Authorization: `Bearer ${await getTokenAsync()}`,
            'content-type': 'application/json',
          }),
        },
      ).then(getJsonOrThrow);

      fetch(
        `https://sheets.googleapis.com/v4/spreadsheets/${id}/values:batchGet?ranges=C2:C&ranges=F:Z`,
        {
          headers: new Headers({
            Authorization: `Bearer ${await getTokenAsync()}`,
            'content-type': 'application/json',
          }),
        },
      )
        .then(getJsonOrThrow)
        .then(async (json) => {
          const { sheetId } = (await propsPromise).sheets[0].properties;
          const ranges = json.valueRanges;
          const userIds = (ranges[0].values || []).map(([el]) => el);
          const r1 = ranges[1].values || [];
          const questions = r1.shift() || [];
          const answers = r1;
          cb({
            userIds,
            questions,
            answers,
            sheetId,
          });
        });
    },
    async addToExisting({ collected, docId }, cb) {
      const sheet = await new Promise((resolve) => this.getSheetInfo(docId, resolve));

      const collectedQuestions = [...collected.headSet].slice(5);
      const questions = new Set([...sheet.questions, ...collectedQuestions]);

      const filteredRecords = collected.records.filter((record) => {
        const userId = record[2][1];
        const userIndexes = sheet.userIds.map((id, i) => (id === userId ? i : '')).filter(String);
        if (userIndexes.length === 0) {
          return true;
        }
        const recordObj = recordToObject(record);
        const ifDuplicate = userIndexes.some(
          (userIndex) => (
            [...questions].every((question, questionIndex) => (recordObj[question] || '') === ((sheet.answers[userIndex]
                || {/* No answers. */})[questionIndex] || ''))
          ),
        );
        if (!ifDuplicate) {
          return true;
        }
        return false;
      });
      if (filteredRecords.length === 0) {
        cb(docId);
        return;
      }
      const newHead = [...[...collected.headSet].slice(0, 5), ...questions];

      // Append new records, update title with new questions.
      // 1) https://developers.google.com/sheets/api/reference/rest/v4/spreadsheets/batchUpdate
      // 2) https://developers.google.com/sheets/api/reference/rest/v4/spreadsheets/request#Request
      fetch(
        `https://sheets.googleapis.com/v4/spreadsheets/${docId}:batchUpdate`,
        {
          method: 'POST',
          headers: new Headers({
            Authorization: `Bearer ${await getTokenAsync()}`,
            'content-type': 'application/json',
          }),
          body: JSON.stringify({
            requests: [
              {
                updateCells: {
                  rows: [
                    {
                      values: newHead.map(
                        (headLabel) => ({
                          userEnteredValue: { stringValue: headLabel },
                        }),
                      ),
                    },
                  ],
                  fields: 'userEnteredValue',
                  range: {
                    sheetId: sheet.sheetId,
                    startColumnIndex: 0,
                    startRowIndex: 0,
                    endRowIndex: 1,
                  },
                },
              },
              {
                appendCells: {
                  fields: 'userEnteredValue',
                  sheetId: sheet.sheetId,
                  rows: filteredRecords.map((record) => {
                    const recordObj = recordToObject(record);
                    const newValues = newHead.map((header) => recordObj[header] || '');
                    return {
                      values: newValues.map((value) => ({
                        userEnteredValue: { stringValue: value },
                      })),
                    };
                  }),
                },
              },
            ],
          }),
        },
      )
        .then(getJsonOrThrow)
        .then(() => cb(docId));
    },
    genNew: function genNew({ collected, groupName }) {
      const result = {
        properties: {
          title: groupName,
        },
        sheets: [{
          data: [{
            startRow: 0,
            startColumn: 0,
            rowData: [
              {
                values: [...collected.headSet].map((header) => (
                  { userEnteredValue: { stringValue: header.toString() } }
                )),
              },
              ...collected.records.map(recordToObject).map((recordObj) => ({
                values: [...collected.headSet].map((question) => (
                  { userEnteredValue: { stringValue: recordObj[question] || '' } }
                )),
              })),
            ],
          }],
        }],
      };
      return result;
    },
    createNew: async function createNew({
      collected,
      groupId,
      groupName,
    },
    cb) {
      fetch(
        'https://sheets.googleapis.com/v4/spreadsheets',
        {
          method: 'POST',
          headers: new Headers({
            Authorization: `Bearer ${await getTokenAsync()}`,
            'content-type': 'application/json',
          }),
          body: JSON.stringify(window.sheetApi.genNew({ collected, groupName })),
        },
      )
        .then(getJsonOrThrow)
        .then(async (msg) => {
          const { groupIdToGroup } = await window.apis.storage.get();
          groupIdToGroup[groupId] = {
            docId: msg.spreadsheetId,
            groupName,
          };
          await window.apis.storage.set({ groupIdToGroup });
          cb(msg.spreadsheetId);
        });
    },

  };
})();
