'use strict';

{
  console.log('Extension started.');

  window.Bexer.addGlobalHandler((errorType, errorEvent) => {
    console.log('Global handler caught:', errorType, errorEvent);
    window.lastErrorEvent = errorEvent;
  });

  const { notifyAbout } = window.Bexer.installErrorReporter({
    submissionOpts: {
      sendReportsToEmail: 'gmac-support+owners@googlegroups.com',
      sendReportsInLanguages: ['en', 'ru'],
    },
  });

  chrome.runtime.onMessage.addListener(Bexer.Utils.timeouted(
    (request /* , sender, sendResponse */) => {
      if (request.type === 'error') {
        notifyAbout(request.errorEvent);
      }
    },
  ));
}
