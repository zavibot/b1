'use strict';

{
  const updateGroupInStorage = async (groupId, newGroup) => {
    const groupIdToGroup = await window.apis.storage.get('groupIdToGroup');
    groupIdToGroup[groupId] = Object.assign(groupIdToGroup[groupId] || {}, newGroup);
    return window.apis.storage.set({ groupIdToGroup });
  };

  const getDocIdFromStorage = async ({ groupName, groupId }) => {
    const { groupIdToGroup, groupNameToGroup } = await window.apis.storage.get();
    const [groupFromId, groupFromName] = [
      groupIdToGroup[groupId] || {},
      groupNameToGroup[groupName] || {},
    ];
    if (!groupFromId.docId && groupFromName.docId) {
      groupIdToGroup[groupId] = groupFromName;
      delete groupNameToGroup[groupName];
      await window.apis.storage.set({ groupIdToGroup, groupNameToGroup });
    }
    return (groupIdToGroup[groupId] || {}).docId;
  };

  chrome.runtime.onMessage.addListener(Bexer.Utils.timeouted({
    returnValue: true,
    cb: async (request, sender, sendResponse) => {
      switch (request.type) {
        case 'setDocId': {
          const { docId, groupId, groupName } = request;
          console.log('Received setDocId for id: ' + docId);
          await updateGroupInStorage(groupId, { docId, groupName });
          sendResponse(docId);
          break;
        }
        case 'pushRecords': {
          const {
            collectedInfo,
            docId,
            groupId,
            groupName,
          } = request;

          const collected = {
            records: collectedInfo,
          };
          collected.headSet = collectedInfo.reduce((acc, record) => {
            record.map(([prop/* , value */]) => prop).forEach((prop) => acc.add(prop));
            return acc;
          }, new Set());

          if (docId) {
            window.sheetApi.addToExisting({ collected, docId }, sendResponse);
          } else {
            window.sheetApi.createNew({
              collected,
              groupId,
              groupName,
            }, async (newDocId) => {
              await updateGroupInStorage(groupId, { docId: newDocId, groupName });
              sendResponse(newDocId);
            });
          }
          break;
        }
        case 'unlink': {
          const { groupId, groupName } = request;
          const { groupIdToGroup, groupNameToGroup } = await window.apis.storage.get();
          delete groupIdToGroup[groupId];
          delete groupNameToGroup[groupName];
          await window.apis.storage.set({ groupIdToGroup, groupNameToGroup });
          console.log('Unlinked, sending response...');
          sendResponse();
          break;
        }
        case 'getDocId': {
          sendResponse(await getDocIdFromStorage(request));
          break;
        }
        case 'error':
          // Handled in error reporter.
          break;
        default:
          throw new TypeError(`Unkown request type '${request.type}'!`);
      }
    },
  }));
}
