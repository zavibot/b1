'use strict';

const migrateFromV2 = (cb) => {
  chrome.storage.local.get(null, Bexer.Utils.workOrDie((storage) => {
    console.log('Starting migration...');
    const groupNameToGroup = Object.entries(storage.data.groups)
      .reduce((acc, [groupName, group]) => {
        console.log(`${groupName} -> ${group.docId}`);
        acc[groupName] = {
          docId: group.docId,
          name: groupName,
        };
        return acc;
      }, {});
    chrome.storage.sync.set({ groupNameToGroup, groupIdToGroup: {} }, Bexer.Utils.workOrDie(() => {
      console.log('Migrated successfully!');
      cb();
    }));
  }));
};

window.migrationPromise = (async () => {

  const ifLocalStorage = await new Promise((resolve) =>
    chrome.storage.local.get(null, Bexer.Utils.workOrDie((localStorage) =>
      resolve(Object.keys(localStorage).length !== 0),
    ),
  ));

  const ifSyncStorage = await new Promise((resolve) =>
    chrome.storage.sync.get(null, Bexer.Utils.workOrDie((syncStorage) =>
      resolve(Object.keys(syncStorage).length !== 0),
    ),
  ));

  const ifMigratingFromV2 = ifLocalStorage && !ifSyncStorage;
  const storage = await window.apis.storage.get();

  const currentVersion = chrome.runtime.getManifest().version;
  let previousVersion;

  if (ifMigratingFromV2) {
    previousVersion = '2.0.0';
  } else {
    if (!storage.version) {
      previousVersion = '3.0.12';
    } else {
      previousVersion = storage.version;
    }
  }

  if (previousVersion !== currentVersion) {
    console.log(`Updating from ${previousVersion} to ${currentVersion}...`);
    if (window.apis.version.isLess(previousVersion, '3.0.0')) {
      await new Promise((resolve) => migrateFromV2(resolve));
    }
  }
  return window.apis.storage.set({ version: currentVersion });
})();
