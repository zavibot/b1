'use strict';

(async () => {
  console.log('Main bg script started.');

  await window.migrationPromise;
  console.log('Migration is finished.');

  if (Object.entries(await window.apis.storage.get()).length < 2 /* Just version or nothing. */ ) {
    console.log('No storage set, initializing it.');
    await window.apis.storage.set({
      groupIdToGroup: {},
      groupNameToGroup: {},
    });
  }

  chrome.tabs.query(
    { url: '*://*.facebook.com/*' },
    Bexer.Utils.workOrDie((tabs) => (
      tabs.forEach((tab) => chrome.tabs.reload(tab.id))
    )),
  );
})();
