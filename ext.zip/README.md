7z l ext.zip
